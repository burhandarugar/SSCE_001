package com.jap.replaceinteger;
public class ArrayPairSum 
{

    public static void main(String[] args) 
    {
        int[] numberArray= {12,13,14,15,16};
        ArrayPairSum arrayPairSum = new ArrayPairSum();
        int sumArray[] = arrayPairSum.sumOfArrayPair(numberArray);
        for(int data:sumArray)
        	System.out.println(data);
    }

    public int[] sumOfArrayPair(int numberArray[])
    {
    	int i,j,size = (numberArray.length+1)/2; 
    	int [] arr = new int[size];
    	for(j=0,i=0;i<numberArray.length;j++,i=i+2)
    	{   if(i!=numberArray.length -1)
    		arr[j]=numberArray[i]+numberArray[i+1];
    	}
    	if(i==(numberArray.length+1))
    		arr[j-1]=numberArray[i-2];
    	return arr;	
    }
}
